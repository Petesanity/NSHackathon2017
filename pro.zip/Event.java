
public class Event {
	
	
	private String day;
	private String month [] ={"january", "february", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
	private String name = " ";
	//if the event 
	//add a countdown
	//if the date is over 3 months
	//disabilities
	//tell 
	
	public Event(String d, String name){
		day = d;
		this.name = name;
		//month = m;
	}
	
	
	
	public String getDay(){
		
		return day;
	}
	
	public String[] getMonth(){
		return month;
	}
	
	
	 
	
	
	
	
	

}
