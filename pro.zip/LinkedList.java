
public class LinkedList<I>  {
	
	
	//private User object;
	
	private LinkedListNode<I> head = null;
	private LinkedListNode<I> tail = null;
	private int size =0;
	
	
	
	
	public int size() {
		// TODO Auto-generated method stub
		return size;
	}

	
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return (size == 0);
	}

	
	public void add(I obj) {
		// TODO Auto-generated method stub
		LinkedListNode<I> newNode = new LinkedListNode<I>(obj, null);
		
		if(isEmpty()){
			head = newNode;
			tail = newNode;
		}else{
			tail.setNext(newNode);
			tail = newNode;
		}
		size++;
		
		
	}

	
	public boolean add(I obj, int index) {
		// TODO Auto-generated method stub
		boolean success = false;
		
		if(index >= 0 && index < size){
			
			LinkedListNode<I> newNode = new LinkedListNode<I>(obj);
			LinkedListNode<I> curNode = head;
			LinkedListNode<I> prevNode = null;
			int curIndex = 0;
			
			while(curIndex != index){
				prevNode = curNode;
				curNode = curNode.getNext();
				curIndex++;
			}
			
			prevNode.setNext(newNode);
			newNode.setNext(curNode);
			success = true;
			size++;
		}
		
		
		
		
		return success;
	}

	
	public boolean addSorted(I obj) {
		// TODO Auto-generated method stu
		boolean success = true;
		
		LinkedListNode<I> newNode = new LinkedListNode<I>(obj);
		LinkedListNode<I> prevNode = null;
		LinkedListNode<I> curNode = head;
		
		while (curNode != null) {
			Integer integerObj = null, integerCur = null;
			if (obj instanceof Integer) {
				integerObj = (Integer) obj;
			} else {
				return false;
			}
			
			if (curNode.getData() instanceof Integer) {
				integerCur = (Integer) curNode.getData();
			} else {
				return false;
			}
			
			int result = integerCur.compareTo(integerObj);
			
			if (result >= 0) {
				break;
			}
			
			prevNode = curNode;
			curNode = curNode.getNext();
		}

		if (curNode == head) {
			newNode.setNext(head);
			head = newNode;
		} else if (curNode == null) {
			tail.setNext(newNode);
			tail = newNode;
		} else {
			newNode.setNext(curNode);
			prevNode.setNext(newNode);
		}		

		this.size++;
		
		return success;

	}

	
	public I get(int index) {
		// TODO Auto-generated method stub
		I returnObject = null;
		
		if((index >=0) &&(index < size)) {
			LinkedListNode <I> curNode = head;
			int curIndex =0;
			
			while(curIndex != index){
				curNode = curNode.getNext();
				curIndex++;
			}
			returnObject = curNode.getData();
		}
		return returnObject;
	}

	
	public I replace(I obj, int index) {
		// TODO Auto-generated method stub
		I replaceObject = null;
		
		if((index>= 0) && (index < size)){
			
			LinkedListNode <I> curNode = head;
			int curIndex = 0;
			
			while(curIndex != index){
				curNode = curNode.getNext();
				curIndex++;
			}
			
			replaceObject = curNode.getData();
			
			curNode.setData(obj);
			
			
		}
		
		
		return replaceObject;
	}

	
	public boolean remove(int index) {
		// TODO Auto-generated method stub
		boolean success = false;
		
		if((index >=0) && (index<size)){
			if(index ==0){
				head = head.getNext();
			}else{
				LinkedListNode<I> curNode = head.getNext();
				LinkedListNode<I> prevNode = head;
				int curIndex = 1;
				while(curIndex != index){
					prevNode = prevNode.getNext();
					curNode = curNode.getNext();
					curIndex++;
					
				}
				prevNode.setNext(curNode.getNext());
				if(curNode == tail){
					tail = prevNode;
				}
			}
			size--;
			success = true;
		}
		return success;
	}

	
	public void removeAll() {
		// TODO Auto-generated method stub
		head = null;
		tail=null;
		size =0;
		
	}
	
	
	@Override
	public String toString(){
		
		String s = new String("{");
		
		LinkedListNode<I> curNode = head;
		
		while(curNode != null){
			s = s.concat(curNode.getData() + ", ");
			
			curNode = curNode.getNext();
			
			
		}
		s = s.concat("}");
		
		
		
		return s;
		
	}
	

	
}


