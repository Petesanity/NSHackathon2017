public class LinkedListNode<I> {
	
	//private I data;
	private I Userdata;
	private LinkedListNode<I> next;

	public LinkedListNode(I data) {
		this.Userdata = data;
		this.next = null;
	}
	
	public LinkedListNode(I data, LinkedListNode<I> next) {
		this.Userdata = data;
		this.next = next;
	}
	
	public I getData() {
		return Userdata;
	}
	public void setData(I data) {
		this.Userdata = data;
	}
	public LinkedListNode<I> getNext() {
		return next;
	}
	public void setNext(LinkedListNode<I> next) {
		this.next = next;
	} 

}
