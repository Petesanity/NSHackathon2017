import java.util.Scanner;
import javax.swing.JOptionPane;
      public class Driver {
	
	
	//String[] tips = new String[10];
	//tips[0] = "stuff";

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		LinkedList<User> ls = new LinkedList<User>();
		
		
		
		
		Scanner input = new Scanner(System.in);
		//String x = input.nextLine();
		//System.out.println("please enter your first name");
		
		//String fn = input.nextLine();
		String fn = JOptionPane.showInputDialog("enter first name");
		//String fn = x;
		String ln = JOptionPane.showInputDialog("enter last name");
		//System.out.println("please enter your last name" );
		//String ln = input.nextLine();
		
		String age = JOptionPane.showInputDialog("enter your age");
		
		int num = Integer.parseInt(age);
		
		//while(num  < 0 || num >115){
			//age = JOptionPane.showInputDialog(" please enter your age");
		//}
		
		//System.out.println("please enter your age" );
		//int age = input.nextInt();
		
		
		String username = JOptionPane.showInputDialog("enter your username");
		
		String pass = JOptionPane.showInputDialog("enter your password");
		
		//String un = input.nextLine();
		
		
		User U = new User(fn, ln, username, num);
		
		System.out.println(" do you have a disability? please type yes or no");
		String ans = input.nextLine();
		
		String message;
		
		while(!ans.equals("yes")&& !ans.equals("no")){
			System.out.println("please say 'yes' or 'no'");
			ans = input.nextLine();
		}
		
		if(ans.equals("yes")){
			U.setdisability(true);
			System.out.println("please type your disability");
			message = input.nextLine();
			
		}
		if(ans.equals("no")){
			U.setdisability(false);
			//System.out.println("");
		}else{
			System.out.println("it works");
		}
		
		ls.add(U);
		System.out.println(U.getUserName());
		
		System.out.println(ls.get(0));
		System.out.println(ls.get(0).getfirstName());
		
	
		
		
		
		
		
		
		//System.out.println("please enter a password" );
		//String p= input.nextLine();
		//User.setPassword(p);
		
		
		
		
		
	}

}
                                                                          