
public class User {
	
	////private K key;
	//private V value;      
	
	private int age;
	private String UserName;
	private String firstName = " ";
	private String lastName;
	
	private boolean disability = false;
	
	private String message ="None";
	private String password  = " ";
	
	
	
	///progress of the game;
	
	
	public User(String fn, String ln, String un, int age ){
		firstName = fn;
		lastName = ln;
		UserName = un;
		this.age = age;
		
	}
	
	
	
	public String getUserName(){
		return UserName;
		
	}
	
	public String getfirstName(){
		return firstName;
	}
	
	public String getlastName(){
		return lastName;
	}
	
	public void setdisability(boolean ans){
		disability = ans;
	}
	
	private boolean getdis(){
		return disability;
	}
	
	public void setPassword(String s){
		password = s;
	}
	
	public void setMessage(String s ){
		message = s;
	}
	
	public String getMessage(){
		return message;
	}
	
	
	

}
