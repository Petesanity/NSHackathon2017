
public class QAList<Q, A>{

	protected QANode<Q, A> head = null;
	protected QANode<Q, A> tail = null;
	protected int size = 0;
		
	public int size() {
		return this.size;
	}

	public boolean isEmpty() {
		return (this.size == 0);
	}

	public void add(QAItem<Q, A> obj) {
		QANode<Q, A> newNode = new QANode<Q, A>(obj);
			
		if(isEmpty()){
			head = newNode;
			tail = newNode;
		}else{
			tail.setNext(newNode);
			tail = newNode;
		}
	size++;
	}

	public boolean add(QAItem<Q, A> obj, int index) {
			
		boolean success = false;
			
		if(index >= 0 && index < size){
				
			QANode<Q, A> newNode = new QANode<Q, A>(obj);
			QANode<Q, A> curNode = head;
			QANode<Q, A> prevNode = null;
			int curIndex = 0;
			
			while(curIndex != index){
				prevNode = curNode;
				curNode = curNode.getNext();
				curIndex++;
			}
				
			prevNode.setNext(newNode);
			newNode.setNext(curNode);
			success = true;
			size++;
		}
					
		return success;
	}

//	public boolean addSorted(QAItem<K, Q, A> obj) {
//
//		boolean success = true;
//			
//		QANode<K, Q, A> newNode = new QANode<K, Q, A>(obj);
//		QANode<K, Q, A> prevNode = null;
//		QANode<K, Q, A> curNode = head;
//		
//		while (curNode != null) {
//			Integer integerObj = null, integerCur = null;
//			if (obj instanceof Integer) {
//				integerObj = (Integer) obj;
//			} else {
//				return false;
//			}
//				
//			if (curNode.getQAItem() instanceof Integer) {
//				integerCur = (Integer) curNode.getQAItem();
//			} else {
//				return false;
//			}
//				
//			int result = integerCur.compareTo(integerObj);
//				
//			if (result >= 0) {
//				break;
//			}
//				
//			prevNode = curNode;
//			curNode = curNode.getNext();
//		}
//
//		if (curNode == head) {
//			newNode.setNext(head);
//			head = newNode;
//		} else if (curNode == null) {
//			tail.setNext(newNode);
//			tail = newNode;
//		} else {
//			newNode.setNext(curNode);
//			prevNode.setNext(newNode);
//		}		
//
//		this.size++;
//		
//		return success;
//
//	}

	
	public QAItem<Q, A> get(int index) {

		QAItem<Q, A> returnObject = null;
			
		if((index >=0) &&(index < size)) {
			QANode<Q, A> curNode = head;
			int curIndex =0;
				
			while(curIndex != index){
				curNode = curNode.getNext();
				curIndex++;
			}
			returnObject = curNode.getQAItem();
		}
		return returnObject;
	}

	public QAItem<Q, A> replace(QAItem<Q, A> obj, int index) {
		
		QAItem<Q, A> replaceObject = null;
			
		if((index>= 0) && (index < size)){
				
			QANode<Q, A> curNode = head;
			int curIndex = 0;
				
			while(curIndex != index){
				curNode = curNode.getNext();
				curIndex++;
			}
				
			replaceObject = curNode.getQAItem();
				
			curNode.setQAItem(obj);
				
			}
		return replaceObject;
	}

	public boolean remove(int index) {
		
		boolean success = false;
			
		if((index >=0) && (index<size)){
			if(index ==0){
				head = head.getNext();
			}else{
				QANode<Q, A> curNode = head.getNext();
				QANode<Q, A> prevNode = head;
				int curIndex = 1;
				while(curIndex != index){
					prevNode = prevNode.getNext();
					curNode = curNode.getNext();
					curIndex++;
						
				}
				prevNode.setNext(curNode.getNext());
				if(curNode == tail){
					tail = prevNode;
				}
			}
			size--;
			success = true;
		}
		return success;
	}

	public void removeAll() {
		// TODO Auto-generated method stub
		head = null;
		tail=null;
		size =0;	
	}	
		
	public String toString(){
			
		String s = new String("{");
			
		QANode<Q, A> curNode = head;
			
		while(curNode != null){
			s = s.concat(curNode.getQAItem() + ", ");
				
			curNode = curNode.getNext();
				
				
		}
		s = s.concat("}");
		return s;
			
	}
	
}
