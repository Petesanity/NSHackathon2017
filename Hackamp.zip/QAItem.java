
public class QAItem<Q, A> {

		private Q question;
		private A answer;
		
		public QAItem() {
			question = null;
			answer = null;
		}
		
		public QAItem(Q question, A answer) {
			this.question = question;
			this.answer = answer;
		}

		public Q getQuestion() {
			return question;
		}

		protected void setQuestion(Q question) {
			this.question = question;
		}

		public A getAnswer() {
			return answer;
		}

		protected void setAnswer(A answer) {
			this.answer = answer;
		}


}
