
public class QANode<Q, A>{

		private QAItem<Q, A> qAItem;
		
		private QANode<Q, A> next;
		
		public QANode() {
			this.qAItem = null;
			this.next = null;
		}
		
		public QANode(QAItem<Q, A> qAItem) {
			this.qAItem = qAItem;
			this.next = null;
		}

		public QANode<Q, A> getNext() {
			return next;
		}
		
		public void setQAItem(QAItem<Q, A> qAItem) {
			this.qAItem = qAItem;
		}

		public void setNext(QANode<Q, A> next) {
			this.next = next;
		}


		public QAItem<Q, A> getQAItem() {
			return qAItem;
		}
	
}
