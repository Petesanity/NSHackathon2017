import java.util.Scanner;

public class HackampAppHelp<Q, A>{

	private static Scanner input = new Scanner(System.in);
	private static int counter = 0;
	private static int key;
	private Q question;
	private A answer;
	QAList<Q, A> NAList = new QAList<Q, A>();
	QAList<Q, A> AAList = new QAList<Q, A>();
	QAItem<Q, A> item = new QAItem<Q, A>();
	
	
	private  void question() {
		
		System.out.println("type in your Question here: ");
		String q = input.nextLine();
		
		key = counter + 1;
		
		if(question instanceof String) {
			question = (Q) q;
		}
		item.setQuestion(question);
		
		QANode<Q, A> node = new QANode<Q, A>();
		node.setQAItem(item);
		notAnswered(node);
	}
	
	private void notAnswered(QANode<Q, A> newNode) {
		if (NAList.isEmpty()){
			NAList.head = newNode;
			NAList.tail = newNode;
		}else{
			NAList.tail.setNext(newNode);
			NAList.tail = newNode;
		}
	}
	
	public static void main(String[] args) {
		HackampAppHelp hAH = new HackampAppHelp();
		System.out.println("Welcome to Hackamp's Help page! Here, "
				+ "you can ask any tech-based questions you may need help with,"
				+ " or help answer a question previously asked by someone else!");
		
		System.out.println("Would you like to post a question, or respond with an answer"
				+ " (Respond 'q' for question, or 'a' for answer)? ");
		
		String response = input.nextLine();
		
		while((!(response.equals("q"))) && (!(response.equals("a")))){
			System.out.println("Error: Please type in 'q' or 'a'.");
			response = input.nextLine();
		}
		
		if(response.equals("q")){
			question();
			System.out.println("Thank you for taking the time to ask us your question. "
					+ "We shall answer it shortly!");
		}else if(response.equals("a")){
//			answer();
		}
		
	}
	 
}
